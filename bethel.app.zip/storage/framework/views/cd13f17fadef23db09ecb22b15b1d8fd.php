<?php $__env->startSection('title', 'Sign In'); ?>
<?php $__env->startSection('meta_description', 'Sign in to your BethelApp account.'); ?>

<?php $__env->startSection('content'); ?>
    <div id="bethel-login"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\bethel.app\resources\views/auth/login.blade.php ENDPATH**/ ?>