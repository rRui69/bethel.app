
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startPush('head'); ?>
<script>
    window.__ADMIN_DATA__ = <?php echo json_encode($adminData); ?>;
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\bethel.app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>