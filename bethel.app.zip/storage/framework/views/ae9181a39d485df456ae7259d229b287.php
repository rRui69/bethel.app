

<?php $__env->startSection('title', 'User Management'); ?>

<?php $__env->startPush('head'); ?>
<script>
    window.__ADMIN_DATA__ = <?php echo json_encode($adminData); ?>;
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\bethel.app\resources\views/admin/users.blade.php ENDPATH**/ ?>