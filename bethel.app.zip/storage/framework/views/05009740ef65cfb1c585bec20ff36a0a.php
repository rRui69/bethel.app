

<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('meta_description', 'BethelApp — Find your parish, view mass schedules, announcements, and book sacramental appointments.'); ?>

<?php $__env->startSection('content'); ?>

    
    <?php $__env->startPush('head'); ?>
    <script>
        window.__PAGE_DATA__ = <?php echo json_encode($pageData); ?>;
    </script>
    <?php $__env->stopPush(); ?>

    
    <div id="bethel-home"></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\bethel.app\resources\views/parishioner/home.blade.php ENDPATH**/ ?>