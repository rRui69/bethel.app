<footer class="bethel-footer" role="contentinfo">
    <div class="container">
        <div class="row g-4">

            
            <div class="col-lg-4 col-md-6">
                

                
                

                
                <div id="bethel-footer-brand"></div>

                <p style="font-size:0.875rem;line-height:1.7;max-width:280px;">
                    Your one-stop hub for parish life. Connect with your parish, schedule sacraments, and stay updated.
                </p>
            </div>

            
            <div class="col-lg-2 col-md-6 col-6">
                <h6 class="bethel-footer__heading">Quick Links</h6>
                <a href="<?php echo e(url('/')); ?>">Home</a>
                <a href="<?php echo e(url('/mass-schedule')); ?>">Mass Schedule</a>
                <a href="<?php echo e(url('/announcements')); ?>">Announcements</a>
                <a href="<?php echo e(url('/events')); ?>">Events</a>
                <a href="<?php echo e(url('/contact')); ?>">Contact Us</a>
            </div>

            
            <div class="col-lg-2 col-md-6 col-6">
                <h6 class="bethel-footer__heading">Sacraments</h6>
                <a href="<?php echo e(url('/sacraments/baptism')); ?>">Baptism</a>
                <a href="<?php echo e(url('/sacraments/marriage')); ?>">Marriage</a>
                <a href="<?php echo e(url('/sacraments/confirmation')); ?>">Confirmation</a>
                <a href="<?php echo e(url('/sacraments/confession')); ?>">Confession</a>
                <a href="<?php echo e(url('/sacraments/communion')); ?>">First Communion</a>
                <a href="<?php echo e(url('/sacraments/anointing')); ?>">Anointing</a>
            </div>

            
            <div class="col-lg-4 col-md-6">
                <h6 class="bethel-footer__heading">Get In Touch</h6>
                <div class="d-flex flex-column gap-2">
                    <div class="d-flex align-items-start gap-2" style="font-size:0.875rem;">
                        <i class="bi bi-envelope mt-1" style="color:var(--bethel-secondary);flex-shrink:0;"></i>
                        <span>helpdesk@bethelapp.com</span>
                    </div>
                    <div class="d-flex align-items-start gap-2" style="font-size:0.875rem;">
                        <i class="bi bi-telephone mt-1" style="color:var(--bethel-secondary);flex-shrink:0;"></i>
                        <span>+63 9123-4321</span>
                    </div>
                    <div class="d-flex align-items-start gap-2" style="font-size:0.875rem;">
                        <i class="bi bi-geo-alt mt-1" style="color:var(--bethel-secondary);flex-shrink:0;"></i>
                        <span>Philippines</span>
                    </div>
                </div>
            </div>

        </div>

        
        <div class="bethel-footer__bottom d-flex flex-column flex-sm-row justify-content-between align-items-center gap-2">
            <span>© <?php echo e(date('Y')); ?> BethelApp. All rights reserved.</span>
        </div>

    </div>
</footer><?php /**PATH D:\laragon\www\bethel.app\resources\views/partials/footer.blade.php ENDPATH**/ ?>