<?php $__env->startSection('title', 'Register'); ?>
<?php $__env->startSection('meta_description', 'Create your BethelApp account and connect with your parish.'); ?>

<?php $__env->startSection('content'); ?>
    <div id="bethel-register"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\bethel.app\resources\views/auth/register.blade.php ENDPATH**/ ?>