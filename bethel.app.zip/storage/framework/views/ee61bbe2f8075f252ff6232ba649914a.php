
<?php $__env->startSection('title', 'Coming Soon'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-center" style="min-height:60vh;">
    <div class="text-center">
        <i class="bi bi-hammer fs-1 d-block mb-3" style="color:var(--bethel-secondary);"></i>
        <h2 class="fw-bold" style="color:var(--bethel-primary);">Coming Soon</h2>
        <p class="text-muted">This page is under construction. Check back later!</p>
        <a href="<?php echo e(url('/')); ?>" class="btn rounded-pill px-4 mt-2"
           style="background:var(--bethel-primary);color:#fff;">← Back to Home</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\bethel.app\resources\views/coming-soon.blade.php ENDPATH**/ ?>