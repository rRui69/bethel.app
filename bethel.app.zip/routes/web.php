<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\Auth\RegisteredUserController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\UserManagementController;

/*
|--------------------------------------------------------------------------
| Public Routes
|--------------------------------------------------------------------------
*/
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/mass-schedule',     fn () => view('coming-soon'))->name('mass-schedule');
Route::get('/announcements',     fn () => view('coming-soon'))->name('announcements');
Route::get('/events',            fn () => view('coming-soon'))->name('events');
Route::get('/sacraments',        fn () => view('coming-soon'))->name('sacraments');
Route::get('/sacraments/{type}', fn ($type) => view('coming-soon'))->name('sacraments.type');
Route::get('/contact',           fn () => view('coming-soon'))->name('contact');

/*
|--------------------------------------------------------------------------
| Guest Auth Routes
|--------------------------------------------------------------------------
*/
Route::middleware('guest')->group(function () {
    Route::get('/register',        [RegisteredUserController::class,       'create'])->name('register');
    Route::post('/register',       [RegisteredUserController::class,       'store']);
    Route::get('/login',           [AuthenticatedSessionController::class, 'create'])->name('login');
    Route::post('/login',          [AuthenticatedSessionController::class, 'store']);
    Route::get('/forgot-password', fn () => view('coming-soon'))->name('password.request');
});

/*
|--------------------------------------------------------------------------
| Authenticated Routes
|--------------------------------------------------------------------------
*/
Route::middleware('auth')->group(function () {
    Route::get('/profile',     fn () => view('coming-soon'))->name('profile');
    Route::get('/my-bookings', fn () => view('coming-soon'))->name('bookings');
    Route::post('/logout', [AuthenticatedSessionController::class, 'destroy'])->name('logout');
});

/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
*/
Route::prefix('admin')
    ->middleware(['auth', 'super_admin'])
    ->name('admin.')
    ->group(function () {

        // ── Blade pages ───────────────────────────────────────────
        Route::get('/dashboard', [DashboardController::class,    'index'])->name('dashboard');
        Route::get('/users',     [UserManagementController::class, 'page'])->name('users');

        // Placeholder pages
        Route::get('/parishioners',  fn () => view('coming-soon'))->name('parishioners');
        Route::get('/sacraments',    fn () => view('coming-soon'))->name('sacraments');
        Route::get('/events',        fn () => view('coming-soon'))->name('events');
        Route::get('/announcements', fn () => view('coming-soon'))->name('announcements');
        Route::get('/roles',         fn () => view('coming-soon'))->name('roles');

        // ── JSON API ──────────────────────────────────────────────
        Route::prefix('api')->name('api.')->group(function () {

            // IMPORTANT: static routes before wildcard routes
            Route::get('/users/stats',               [UserManagementController::class, 'stats'])->name('users.stats');
            Route::get('/users',                     [UserManagementController::class, 'index'])->name('users.index');
            Route::post('/users',                    [UserManagementController::class, 'store'])->name('users.store');
            Route::get('/users/{user}',              [UserManagementController::class, 'show'])->name('users.show');
            Route::patch('/users/{user}',            [UserManagementController::class, 'update'])->name('users.update');
            Route::delete('/users/{user}',           [UserManagementController::class, 'destroy'])->name('users.destroy');
            Route::post('/users/{user}/reset-password', [UserManagementController::class, 'resetPassword'])->name('users.reset-password');

            // Notifications
            Route::post('/notifications/read',       [UserManagementController::class, 'markNotificationRead'])->name('notifications.read');
        });
    });