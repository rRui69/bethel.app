<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureSuperAdmin
{
    // Roles allowed to access /admin/* routes
    const ADMIN_ROLES = ['super_admin', 'parish_admin', 'clergymen'];

    public function handle(Request $request, Closure $next): Response
    {
        if (!auth()->check() || !in_array(auth()->user()->role, self::ADMIN_ROLES)) {
            abort(403, 'Unauthorized access.');
        }

        return $next($request);
    }
}