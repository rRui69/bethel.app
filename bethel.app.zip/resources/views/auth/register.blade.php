@extends('layouts.app')

@section('title', 'Register')
@section('meta_description', 'Create your BethelApp account and connect with your parish.')

@section('content')
    <div id="bethel-register"></div>
@endsection