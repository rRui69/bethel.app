@extends('layouts.app')

@section('title', 'Sign In')
@section('meta_description', 'Sign in to your BethelApp account.')

@section('content')
    <div id="bethel-login"></div>
@endsection